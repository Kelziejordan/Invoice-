import { BusinessProfile, Client, Item, Invoice, TemplateSettings } from '../types';

const DB_NAME = 'InvoiceStudio2_DB';
const DB_VERSION = 1;

/**
 * Production initial default profile.
 * Fictitious demonstration values have been removed.
 * Default tax treatment defaults to standard 10% GST.
 */
export const DEFAULT_BUSINESS_PROFILE: BusinessProfile = {
  name: '',
  contactEmail: '',
  phone: '',
  address: '',
  website: '',
  taxId: '',
  logoDataUrl: '',
  paymentInstructions: '',
  defaultCurrency: 'AUD',
  defaultTaxLabel: 'GST',
  defaultTaxRate: 10.0,
  invoicePrefix: 'INV-',
  nextInvoiceNumber: 1001
};

export const DEFAULT_TEMPLATE: TemplateSettings = {
  accentColor: '#2563eb',
  fontFamily: 'Inter, sans-serif',
  logoPosition: 'left',
  footerNote: 'Thank you for your business. Please remit payment by the due date.'
};

export function isProfileConfigured(profile: BusinessProfile | null | undefined): boolean {
  if (!profile) return false;
  return Boolean(profile.name && profile.name.trim().length > 0);
}

export class StorageService {
  private dbPromise: Promise<IDBDatabase> | null = null;

  public async openDB(): Promise<IDBDatabase> {
    if (this.dbPromise) {
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve, reject) => {
      if (typeof indexedDB === 'undefined') {
        reject(new Error('IndexedDB is not supported in this browser environment.'));
        return;
      }

      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        if (!db.objectStoreNames.contains('business')) {
          db.createObjectStore('business', { keyPath: 'key' });
        }
        if (!db.objectStoreNames.contains('clients')) {
          const clientStore = db.createObjectStore('clients', { keyPath: 'id' });
          clientStore.createIndex('name', 'name', { unique: false });
        }
        if (!db.objectStoreNames.contains('items')) {
          const itemStore = db.createObjectStore('items', { keyPath: 'id' });
          itemStore.createIndex('name', 'name', { unique: false });
        }
        if (!db.objectStoreNames.contains('invoices')) {
          const invStore = db.createObjectStore('invoices', { keyPath: 'id' });
          invStore.createIndex('invoiceNumber', 'invoiceNumber', { unique: true });
          invStore.createIndex('status', 'status', { unique: false });
          invStore.createIndex('createdAt', 'createdAt', { unique: false });
          invStore.createIndex('clientId', 'clientId', { unique: false });
        }
        if (!db.objectStoreNames.contains('template')) {
          db.createObjectStore('template', { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(new Error(`Failed to open IndexedDB: ${request.error?.message || 'Unknown database error'}`));
      };

      request.onblocked = () => {
        console.warn('IndexedDB blocked: please close other active tabs running Invoice Studio 2.');
      };
    });

    return this.dbPromise;
  }

  /**
   * Runs an operation inside a durable IndexedDB transaction.
   * Resolves ONLY when tx.oncomplete fires, guaranteeing that written data
   * is committed to disk, preventing premature success if the transaction aborts.
   */
  private async runTransaction<T>(
    storeName: string,
    mode: IDBTransactionMode,
    operation: (store: IDBObjectStore) => IDBRequest<T>
  ): Promise<T> {
    try {
      const db = await this.openDB();
      return new Promise<T>((resolve, reject) => {
        const tx = db.transaction(storeName, mode);
        const store = tx.objectStore(storeName);
        let result: T;
        let requestError: DOMException | Error | null = null;

        const request = operation(store);

        request.onsuccess = () => {
          result = request.result;
        };

        request.onerror = () => {
          requestError = request.error || new Error(`IndexedDB request on '${storeName}' failed.`);
        };

        // Durable confirmation: Only resolve when transaction successfully completes & commits
        tx.oncomplete = () => {
          if (requestError) {
            reject(requestError);
          } else {
            resolve(result);
          }
        };

        tx.onabort = () => {
          reject(tx.error || requestError || new Error(`IndexedDB transaction on '${storeName}' was aborted.`));
        };

        tx.onerror = () => {
          if (tx.error && tx.error.name === 'QuotaExceededError') {
            reject(new Error('Local storage quota exceeded. Please export a backup and delete older items.'));
          } else {
            reject(tx.error || requestError || new Error(`IndexedDB transaction on '${storeName}' failed.`));
          }
        };
      });
    } catch (err: unknown) {
      if (err instanceof DOMException && err.name === 'QuotaExceededError') {
        throw new Error('Local storage quota exceeded. Please export a backup and delete older items.');
      }
      throw err;
    }
  }

  // --- Business Profile ---
  async getBusinessProfile(): Promise<BusinessProfile> {
    const row = await this.runTransaction<{ key: string; value: BusinessProfile } | undefined>(
      'business',
      'readonly',
      (store) => store.get('profile')
    );
    return row ? row.value : DEFAULT_BUSINESS_PROFILE;
  }

  async saveBusinessProfile(profile: BusinessProfile): Promise<void> {
    await this.runTransaction('business', 'readwrite', (store) =>
      store.put({ key: 'profile', value: profile })
    );
  }

  // --- Template Settings ---
  async getTemplateSettings(): Promise<TemplateSettings> {
    const row = await this.runTransaction<{ key: string; value: TemplateSettings } | undefined>(
      'template',
      'readonly',
      (store) => store.get('settings')
    );
    return row ? row.value : DEFAULT_TEMPLATE;
  }

  async saveTemplateSettings(settings: TemplateSettings): Promise<void> {
    await this.runTransaction('template', 'readwrite', (store) =>
      store.put({ key: 'settings', value: settings })
    );
  }

  // --- Clients ---
  async getAllClients(): Promise<Client[]> {
    return this.runTransaction<Client[]>('clients', 'readonly', (store) => store.getAll());
  }

  async getClientById(id: string): Promise<Client | undefined> {
    return this.runTransaction<Client | undefined>('clients', 'readonly', (store) => store.get(id));
  }

  async saveClient(client: Client): Promise<void> {
    await this.runTransaction('clients', 'readwrite', (store) => store.put(client));
  }

  async deleteClient(id: string): Promise<void> {
    await this.runTransaction('clients', 'readwrite', (store) => store.delete(id));
  }

  // --- Items ---
  async getAllItems(): Promise<Item[]> {
    return this.runTransaction<Item[]>('items', 'readonly', (store) => store.getAll());
  }

  async getItemById(id: string): Promise<Item | undefined> {
    return this.runTransaction<Item | undefined>('items', 'readonly', (store) => store.get(id));
  }

  async saveItem(item: Item): Promise<void> {
    await this.runTransaction('items', 'readwrite', (store) => store.put(item));
  }

  async deleteItem(id: string): Promise<void> {
    await this.runTransaction('items', 'readwrite', (store) => store.delete(id));
  }

  // --- Invoices ---
  async getAllInvoices(): Promise<Invoice[]> {
    return this.runTransaction<Invoice[]>('invoices', 'readonly', (store) => store.getAll());
  }

  async getInvoiceById(id: string): Promise<Invoice | undefined> {
    return this.runTransaction<Invoice | undefined>('invoices', 'readonly', (store) => store.get(id));
  }

  async saveInvoice(invoice: Invoice): Promise<void> {
    await this.runTransaction('invoices', 'readwrite', (store) => store.put(invoice));
  }

  async deleteInvoice(id: string): Promise<void> {
    await this.runTransaction('invoices', 'readwrite', (store) => store.delete(id));
  }

  // --- Atomic Restore Operation ---
  async restoreWorkspaceData(data: {
    business: BusinessProfile;
    clients: Client[];
    items: Item[];
    invoices: Invoice[];
    template: TemplateSettings;
  }): Promise<void> {
    const db = await this.openDB();
    const storeNames = ['business', 'clients', 'items', 'invoices', 'template'];

    return new Promise<void>((resolve, reject) => {
      const tx = db.transaction(storeNames, 'readwrite');

      tx.oncomplete = () => resolve();
      tx.onabort = () => reject(tx.error || new Error('Atomic restoration was aborted. Previous data preserved.'));
      tx.onerror = () => reject(tx.error || new Error('Atomic restoration failed. Database rolled back.'));

      // 1. Clear all 5 stores
      for (const name of storeNames) {
        tx.objectStore(name).clear();
      }

      // 2. Repopulate all stores within the same atomic transaction
      tx.objectStore('business').put({ key: 'profile', value: data.business });
      tx.objectStore('template').put({ key: 'settings', value: data.template });

      const clientStore = tx.objectStore('clients');
      for (const c of data.clients) {
        clientStore.put(c);
      }

      const itemStore = tx.objectStore('items');
      for (const it of data.items) {
        itemStore.put(it);
      }

      const invStore = tx.objectStore('invoices');
      for (const inv of data.invoices) {
        invStore.put(inv);
      }
    });
  }

  // --- Full Wipe ---
  async clearAllData(): Promise<void> {
    const db = await this.openDB();
    const storeNames = ['business', 'clients', 'items', 'invoices', 'template'];
    return new Promise((resolve, reject) => {
      const tx = db.transaction(storeNames, 'readwrite');
      for (const name of storeNames) {
        tx.objectStore(name).clear();
      }
      tx.oncomplete = () => resolve();
      tx.onerror = () => reject(tx.error);
    });
  }
}

export const storage = new StorageService();
