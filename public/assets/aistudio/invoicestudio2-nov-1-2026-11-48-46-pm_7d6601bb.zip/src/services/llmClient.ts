import { LLMChangeProposal, LLMStatus } from '../types';

type StatusListener = (status: LLMStatus) => void;

class LLMClient {
  private worker: Worker | null = null;
  private currentStatus: LLMStatus = {
    state: 'idle',
    statusMessage: 'Local model ready to load on-device. Zero API keys required.',
    modelName: 'Xenova/flan-t5-small',
    device: 'WebAssembly (On-Device)'
  };
  private listeners: Set<StatusListener> = new Set();
  private pendingTasks: Map<
    string,
    {
      resolve: (res: LLMChangeProposal) => void;
      reject: (err: Error) => void;
      timer: ReturnType<typeof setTimeout>;
    }
  > = new Map();

  constructor() {
    this.initWorker();
  }

  private initWorker() {
    if (typeof Worker === 'undefined') {
      this.updateStatus({
        state: 'error',
        statusMessage: 'Web Workers are not supported in this browser environment.'
      });
      return;
    }

    try {
      this.worker = new Worker(new URL('./llm.worker.ts', import.meta.url), {
        type: 'module'
      });

      this.worker.onmessage = (e: MessageEvent) => {
        const { type, id, status, progress, modelName, error, proposal } = e.data;

        if (type === 'STATUS') {
          this.updateStatus({
            state: status,
            statusMessage:
              status === 'ready'
                ? 'Model loaded and operational offline.'
                : 'Downloading local model weights (~60MB once)...',
            modelName: modelName || this.currentStatus.modelName
          });
        } else if (type === 'PROGRESS') {
          this.updateStatus({
            state: 'downloading',
            progress: progress,
            statusMessage: `Downloading model weights: ${progress}%`
          });
        } else if (type === 'ERROR') {
          this.updateStatus({
            state: 'error',
            statusMessage: error
          });
        } else if (type === 'TASK_SUCCESS') {
          const task = this.pendingTasks.get(id);
          if (task) {
            clearTimeout(task.timer);
            this.pendingTasks.delete(id);
            this.updateStatus({ state: 'ready', statusMessage: 'Ready' });
            task.resolve(proposal);
          }
        } else if (type === 'TASK_ERROR') {
          const task = this.pendingTasks.get(id);
          if (task) {
            clearTimeout(task.timer);
            this.pendingTasks.delete(id);
            this.updateStatus({ state: 'ready', statusMessage: 'Ready' });
            task.reject(new Error(error));
          }
        }
      };

      this.worker.onerror = (err) => {
        this.updateStatus({
          state: 'error',
          statusMessage: `Worker runtime failure: ${err.message || 'Worker thread crashed.'}`
        });
      };
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      this.updateStatus({
        state: 'error',
        statusMessage: `Worker instantiation failed: ${errorMsg}`
      });
    }
  }

  private updateStatus(newStatus: Partial<LLMStatus>) {
    this.currentStatus = { ...this.currentStatus, ...newStatus };
    for (const listener of this.listeners) {
      listener(this.currentStatus);
    }
  }

  public subscribeStatus(listener: StatusListener): () => void {
    this.listeners.add(listener);
    listener(this.currentStatus);
    return () => this.listeners.delete(listener);
  }

  public initializeModel(): void {
    if (!this.worker) return;
    this.worker.postMessage({ type: 'INIT_MODEL' });
  }

  public async requestProposal(userPrompt: string): Promise<LLMChangeProposal> {
    if (!this.worker) {
      throw new Error('Local inference worker is not supported or failed to initialize.');
    }

    if (!userPrompt || userPrompt.trim().length === 0) {
      throw new Error('Please enter a description or prompt for Invoice Buddy.');
    }

    if (userPrompt.length > 500) {
      throw new Error('Prompt exceeds maximum allowable length of 500 characters.');
    }

    const taskId = 'task_' + Math.random().toString(36).substring(2, 9);

    return new Promise<LLMChangeProposal>((resolve, reject) => {
      // 30-second safe timeout
      const timer = setTimeout(() => {
        this.pendingTasks.delete(taskId);
        this.updateStatus({ state: 'ready', statusMessage: 'Task timed out.' });
        reject(
          new Error('Invoice Buddy timed out while generating response (exceeded 30-second execution limit).')
        );
      }, 30000);

      this.pendingTasks.set(taskId, { resolve, reject, timer });
      this.updateStatus({
        state: 'processing',
        statusMessage: 'Invoice Buddy is processing on-device...'
      });

      this.worker?.postMessage({
        type: 'RUN_INVOICE_BUDDY',
        id: taskId,
        payload: { userPrompt }
      });
    });
  }
}

export const llmClient = new LLMClient();
