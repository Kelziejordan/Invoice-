import {
  Client,
  Item,
  InvoiceLineItem,
  BuddyExtractedCustomer,
  BuddyInvoiceDraft
} from '../types';
import { calculateInvoiceTotals } from '../utils/calc';

export interface ProcessBuddyTurnParams {
  userMessage: string;
  previousDraft?: BuddyInvoiceDraft | null;
  existingClients: Client[];
  existingItems: Item[];
  businessDefaults: {
    currency: string;
    taxLabel: string;
    taxRate: number;
    paymentInstructions: string;
  };
}

export interface BuddyTurnResult {
  assistantResponse: string;
  draft: BuddyInvoiceDraft;
  readyToApply: boolean;
}

/**
 * Parses relative date or days string to YYYY-MM-DD
 */
function calculateDueDate(issueDateStr: string, termsText: string): string {
  const baseDate = new Date(issueDateStr);
  if (isNaN(baseDate.getTime())) return issueDateStr;

  const daysMatch = termsText.match(/(\d+)\s*days?/i) || termsText.match(/net\s*(\d+)/i);
  if (daysMatch) {
    const days = parseInt(daysMatch[1], 10);
    const dueDate = new Date(baseDate.getTime() + days * 24 * 60 * 60 * 1000);
    return dueDate.toISOString().split('T')[0];
  }

  if (/on\s*receipt|immediately/i.test(termsText)) {
    return issueDateStr;
  }

  if (/next\s*week/i.test(termsText)) {
    const dueDate = new Date(baseDate.getTime() + 7 * 24 * 60 * 60 * 1000);
    return dueDate.toISOString().split('T')[0];
  }

  if (/end\s*of\s*(?:the\s*)?month/i.test(termsText)) {
    const year = baseDate.getFullYear();
    const month = baseDate.getMonth();
    const lastDay = new Date(year, month + 1, 0);
    return lastDay.toISOString().split('T')[0];
  }

  // Default to 14 days
  const dueDate = new Date(baseDate.getTime() + 14 * 24 * 60 * 60 * 1000);
  return dueDate.toISOString().split('T')[0];
}

/**
 * High-precision conversational invoice parser & accumulator.
 */
export function processBuddyTurn({
  userMessage,
  previousDraft,
  existingClients,
  existingItems,
  businessDefaults
}: ProcessBuddyTurnParams): BuddyTurnResult {
  const text = userMessage.trim();
  const todayStr = new Date().toISOString().split('T')[0];

  // Initialize accumulated draft from previous turn or defaults
  const customer: BuddyExtractedCustomer = {
    ...(previousDraft?.customer || {})
  };

  let lineItems: InvoiceLineItem[] = previousDraft?.lineItems ? [...previousDraft.lineItems] : [];
  let issueDate = previousDraft?.issueDate || todayStr;
  let dueDate = previousDraft?.dueDate || calculateDueDate(todayStr, '14 days');
  let notes = previousDraft?.notes || '';
  const missingFields: string[] = [];
  const uncertainFields: string[] = [];

  // ==========================================
  // 1. Customer Identification & Extraction
  // ==========================================
  // Check if user mentions an existing client by name
  for (const client of existingClients) {
    const escaped = client.name.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
    const clientRegex = new RegExp(`\\b${escaped}\\b`, 'i');
    if (clientRegex.test(text)) {
      customer.name = client.name;
      customer.email = client.email;
      customer.phone = client.phone;
      customer.billingAddress = client.billingAddress;
      customer.matchedClientId = client.id;
      customer.isExisting = true;
      break;
    }
  }

  // If no existing client matched, extract new customer patterns
  if (!customer.name) {
    const customerPatterns = [
      /(?:invoice|bill)\s+(?:for|to)\s+([A-Z0-9][A-Za-z0-9\s.,'&\\-]{2,40}?)(?:,\s*address|,\s*email|\s+for|\s+with|\s+did|\s+done|\.|$)/i,
      /(?:customer|client|bill to|billed to):\s*([A-Za-z0-9\s.,'&\\-]{2,40}?)(?:,\s*address|,\s*email|\s+for|\.|$)/i,
      /(?:for|to)\s+([A-Z][A-Za-z0-9\s.'&\\-]{2,30}?)(?:\s+(?:who|whose|at|with|\.|$))/i
    ];

    for (const pat of customerPatterns) {
      const match = text.match(pat);
      if (match && match[1]) {
        const potentialName = match[1].trim().replace(/\s+(?:and|who|with|did)$/i, '');
        // Exclude common false positives like "5 hours", "10 units"
        if (!/^\d+\s*(?:hours|hrs|days|units|items)/i.test(potentialName)) {
          customer.name = potentialName;
          customer.isExisting = false;
          break;
        }
      }
    }
  }

  // Extract Email
  const emailMatch = text.match(/([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})/);
  if (emailMatch) {
    customer.email = emailMatch[1];
  }

  // Extract Phone Number
  const phoneMatch = text.match(/(?:phone|tel|ph|mobile)?[:\s]*(\+?\d{1,4}?[-.\s]?\(?\d{1,4}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,9})/i);
  if (phoneMatch && phoneMatch[1].replace(/\D/g, '').length >= 8) {
    // avoid matching small numbers like 100 or dates
    const digits = phoneMatch[1].replace(/\D/g, '');
    if (digits.length >= 8 && digits.length <= 15) {
      customer.phone = phoneMatch[1].trim();
    }
  }

  // Extract Billing Address
  const addressMatch = text.match(/(?:address|located at|billing address)[:\s]+([^.\n,]+(?:,\s*[^.\n,]+){1,3})/i);
  if (addressMatch) {
    customer.billingAddress = addressMatch[1].trim();
  }

  // ==========================================
  // 2. Dates & Payment Terms Extraction
  // ==========================================
  const termsMatch = text.match(/(?:due\s+(?:in|within|on)|terms?:?\s*(?:of|are)?|net\s*)\s*(\d+\s*days?|\d{4}-\d{2}-\d{2}|eom|receipt|[^.,\n]+)/i);
  if (termsMatch) {
    dueDate = calculateDueDate(issueDate, termsMatch[1]);
  }

  const explicitDueMatch = text.match(/due(?:\s+date)?[:\s]+(\d{4}-\d{2}-\d{2})/i);
  if (explicitDueMatch) {
    dueDate = explicitDueMatch[1];
  }

  const issueDateMatch = text.match(/(?:issue|issued|invoice)\s+date[:\s]+(\d{4}-\d{2}-\d{2})/i);
  if (issueDateMatch) {
    issueDate = issueDateMatch[1];
  }

  // ==========================================
  // 3. Notes / Memo Extraction
  // ==========================================
  const notesMatch = text.match(/(?:notes?|memo|po(?:\s*number)?|reference)[:\s]+([^.\n]+)/i);
  if (notesMatch) {
    notes = notesMatch[1].trim();
  }

  // ==========================================
  // 4. Line Items & Services Extraction
  // ==========================================
  // Prepare text for line item extraction by stripping dates, terms, customer headers, and notes
  let itemText = text;

  // Strip terms/due-date cues so "due in 14 days" is never mistaken for item quantity
  itemText = itemText.replace(/(?:due\s+(?:in|within|on)|terms?:?\s*(?:of|are)?|net\s*)\s*(\d+\s*days?|\d{4}-\d{2}-\d{2}|eom|receipt|[^.,\n;]+)/gi, ' ');
  itemText = itemText.replace(/due(?:\s+date)?[:\s]+\d{4}-\d{2}-\d{2}/gi, ' ');
  itemText = itemText.replace(/(?:issue|issued|invoice)\s+date[:\s]+\d{4}-\d{2}-\d{2}/gi, ' ');

  // Strip customer introduction header so customer name is not mistaken for a line item
  if (customer.name) {
    const escapedName = customer.name.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&');
    itemText = itemText.replace(new RegExp(`(?:invoice|bill|quote)\\s+(?:for|to)\\s+${escapedName}\\s*(?:for|with|doing|did|done|:|,)?`, 'i'), ' ');
    itemText = itemText.replace(new RegExp(`(?:client|customer|billed to)[:\\s]+${escapedName}\\s*(?:for|with|doing|did|done|:|,)?`, 'i'), ' ');
  } else {
    itemText = itemText.replace(/(?:invoice|bill)\s+(?:for|to)\s+[A-Za-z0-9\s.,'&\\-]{2,30}?(?=\s+for\s+\d|\s+with|\s+doing|\s+did|\.|$)/i, ' ');
  }

  // Strip email and phone if matched
  if (customer.email) itemText = itemText.replace(customer.email, ' ');
  if (customer.phone) itemText = itemText.replace(customer.phone, ' ');
  if (customer.billingAddress) itemText = itemText.replace(customer.billingAddress, ' ');

  // Split user input into clauses to identify separate jobs
  const clauses = itemText
    .split(/;\s*|\s+and\s+(?:also\s+)?|\s+plus\s+|\n+|\.\s+(?=[A-Z0-9])/)
    .map((c) => c.trim())
    .filter((c) => c.length >= 3);

  const newlyParsedItems: InvoiceLineItem[] = [];

  for (const clause of clauses) {
    // Check for quantity with unit: "4.5 hours", "2 days", "3 units", etc.
    const qtyWithUnitMatch = clause.match(/(\d+(?:\.\d+)?)\s*(hours|hrs|hr|units|unit|items|item|days|day|sqm|trips|trip|licenses|license|m|km)\b/i);
    // Check for bare count item: "1 waste disposal", "3 replacement valves"
    const bareQtyMatch = clause.match(/^(?:also\s+)?(?:add\s+)?(\d+(?:\.\d+)?)\s+([a-zA-Z][a-zA-Z0-9\s-]{2,40})/i);

    // Rate cues: "$80/hr", "at $90", "for $1200", "$65"
    const hasRate = clause.match(/\$?\s*(\d+(?:\.\d{1,2})?)\s*(?:\/|\s*per\s*)(?:hr|hour|item|unit|day|sqm|mo|month)/i)
      || clause.match(/(?:at|rate of|for)\s*\$?\s*(\d+(?:\.\d{1,2})?)/i)
      || clause.match(/\$\s*(\d+(?:\.\d{1,2})?)/i);

    // Check if any known catalog item name is mentioned in this clause
    let matchedCatalogItem: Item | undefined;
    for (const item of existingItems) {
      if (item.name.length >= 3 && new RegExp(`\\b${item.name.replace(/[-[\]{}()*+?.,\\^$|#\s]/g, '\\$&')}\\b`, 'i').test(clause)) {
        matchedCatalogItem = item;
        break;
      }
    }

    if (qtyWithUnitMatch || bareQtyMatch || hasRate || matchedCatalogItem) {
      let qty = 1;
      let unit = matchedCatalogItem?.unit || 'items';

      if (qtyWithUnitMatch) {
        qty = parseFloat(qtyWithUnitMatch[1]);
        const rawUnit = qtyWithUnitMatch[2].toLowerCase();
        unit = /hour|hr/i.test(rawUnit) ? 'hours' : /day/i.test(rawUnit) ? 'days' : /sqm/i.test(rawUnit) ? 'sqm' : /trip/i.test(rawUnit) ? 'trips' : /unit/i.test(rawUnit) ? 'units' : 'items';
      } else if (bareQtyMatch) {
        qty = parseFloat(bareQtyMatch[1]);
        unit = matchedCatalogItem?.unit || 'units';
      }

      let unitRate = hasRate ? parseFloat(hasRate[1]) : (matchedCatalogItem?.defaultRate ?? 0);
      let rateRequiresConfirmation = false;

      if (!hasRate && !matchedCatalogItem) {
        unitRate = 0;
        rateRequiresConfirmation = true;
      }

      // Clean up description
      let desc = clause;
      if (hasRate && hasRate[0]) {
        desc = desc.replace(hasRate[0], ' ');
      }
      // Remove leading action words and quantity prefixes
      desc = desc
        .replace(/^(?:also\s+|add\s+|did\s+|performed\s+|completed\s+)?\s*\d+(?:\.\d+)?\s*(?:hours|hrs|hr|units|unit|items|item|days|day|sqm|trips|trip|licenses|license|m|km|x)?\s*(?:of\s+)?/i, ' ')
        .replace(/^(?:for|at|with|and|also|plus|performed|did)\s+/i, '')
        .replace(/\s+(?:for|at|with)\s*$/i, '')
        .trim();

      if (desc.length < 3 && matchedCatalogItem) {
        desc = matchedCatalogItem.name;
      }

      // Check taxability
      const isTaxExempt = /tax[- ]?free|gst[- ]?free|no tax|exempt/i.test(clause);
      const taxable = !isTaxExempt;

      if (desc.length >= 3) {
        const lineTotal = Math.round((qty * unitRate + Number.EPSILON) * 100) / 100;
        newlyParsedItems.push({
          id: 'line_' + Math.random().toString(36).substring(2, 8),
          itemId: matchedCatalogItem?.id,
          description: desc,
          quantity: qty,
          unit,
          unitRate,
          taxable,
          lineTotal,
          rateRequiresConfirmation
        });
      }
    }
  }

  // If new items were found, decide whether to append or replace
  if (newlyParsedItems.length > 0) {
    // If previous draft had only 1 item and user is defining line items, or adding
    if (lineItems.length === 0 || /also|and|plus|add/i.test(text)) {
      lineItems = [...lineItems, ...newlyParsedItems];
    } else {
      // Replace with latest parsed items
      lineItems = newlyParsedItems;
    }
  }

  // ==========================================
  // 5. Calculations & Totals
  // ==========================================
  const totals = calculateInvoiceTotals({
    lineItems,
    discountType: 'percentage',
    discountValue: 0,
    taxRate: businessDefaults.taxRate
  });

  // ==========================================
  // 6. Missing Fields & Uncertainty Check
  // ==========================================
  if (!customer.name || customer.name.trim().length === 0) {
    missingFields.push('Customer Name');
  }

  if (lineItems.length === 0) {
    missingFields.push('Services or Line Items');
  } else {
    lineItems.forEach((item, idx) => {
      if (item.rateRequiresConfirmation || item.unitRate === 0) {
        missingFields.push(`Rate for "${item.description.slice(0, 25)}" (currently $0.00)`);
      }
    });
  }

  // ==========================================
  // 7. Formulate Natural Conversational Reply
  // ==========================================
  let assistantResponse = '';
  let readyToApply = false;

  if (missingFields.length === 0) {
    readyToApply = true;
    const itemsSummary = lineItems
      .map((it) => `• ${it.description}: ${it.quantity} ${it.unit} @ $${it.unitRate.toFixed(2)} = $${it.lineTotal.toFixed(2)}`)
      .join('\n');

    assistantResponse = `I've assembled the complete invoice draft for **${customer.name}**:\n\n${itemsSummary}\n\n` +
      `• **Subtotal:** $${totals.subtotal.toFixed(2)}\n` +
      `• **${businessDefaults.taxLabel} (${businessDefaults.taxRate}%):** $${totals.taxAmount.toFixed(2)}\n` +
      `• **Grand Total:** $${totals.grandTotal.toFixed(2)} ${businessDefaults.currency}\n` +
      `• **Due Date:** ${dueDate}\n\n` +
      `Click **"Apply to Invoice Builder"** below to load this invoice for final review and saving!`;
  } else if (!customer.name && lineItems.length > 0) {
    assistantResponse = `I have noted ${lineItems.length} service item(s):\n` +
      lineItems.map((it) => `• ${it.description} (${it.quantity} ${it.unit} @ $${it.unitRate.toFixed(2)})`).join('\n') +
      `\n\nWho is the **customer** for this invoice? (Provide a name, email, or company name).`;
  } else if (customer.name && lineItems.length === 0) {
    assistantResponse = `I've set the client to **${customer.name}**. What jobs, items, or services did you perform for them? You can specify hours, rates, or tasks.`;
  } else if (lineItems.some((it) => it.rateRequiresConfirmation || it.unitRate === 0)) {
    const zeroRateItems = lineItems.filter((it) => it.rateRequiresConfirmation || it.unitRate === 0);
    assistantResponse = `I have set client **${customer.name}** and added ${lineItems.length} item(s). However, I need to confirm the rate for:\n` +
      zeroRateItems.map((it) => `• "${it.description}"`).join('\n') +
      `\nWhat rate should I charge for this, or should it remain $0?`;
  } else {
    assistantResponse = `Tell me about the work: who is the client, and what services, hours, or rates would you like to invoice?`;
  }

  const draft: BuddyInvoiceDraft = {
    customer,
    lineItems,
    issueDate,
    dueDate,
    notes,
    currency: businessDefaults.currency,
    taxLabel: businessDefaults.taxLabel,
    taxRate: businessDefaults.taxRate,
    subtotal: totals.subtotal,
    taxAmount: totals.taxAmount,
    grandTotal: totals.grandTotal,
    missingFields,
    uncertainFields,
    summary: `${customer.name || 'Unnamed Client'} - ${lineItems.length} items - Total: $${totals.grandTotal.toFixed(2)}`
  };

  return {
    assistantResponse,
    draft,
    readyToApply
  };
}
