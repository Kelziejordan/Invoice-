import { pipeline, env } from '@xenova/transformers';

// Configure transformers for local in-browser execution
env.allowLocalModels = false;
env.useBrowserCache = true;

const MODEL_ID = 'Xenova/flan-t5-small';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let generator: any = null;
let isLoading = false;

self.onmessage = async (e: MessageEvent) => {
  const { type, id, payload } = e.data;

  if (type === 'INIT_MODEL') {
    if (generator) {
      self.postMessage({ type: 'STATUS', status: 'ready', modelName: MODEL_ID });
      return;
    }
    if (isLoading) return;

    try {
      isLoading = true;
      self.postMessage({ type: 'STATUS', status: 'downloading', modelName: MODEL_ID });

      // Load on-device text2text generation pipeline with progress callback
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      generator = await pipeline('text2text-generation', MODEL_ID, {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        progress_callback: (progressInfo: any) => {
          if (progressInfo.status === 'progress' && typeof progressInfo.progress === 'number') {
            self.postMessage({
              type: 'PROGRESS',
              progress: Math.round(progressInfo.progress)
            });
          }
        }
      });

      isLoading = false;
      self.postMessage({ type: 'STATUS', status: 'ready', modelName: MODEL_ID });
    } catch (err: unknown) {
      isLoading = false;
      const errorMsg = err instanceof Error ? err.message : String(err);
      self.postMessage({
        type: 'ERROR',
        error: `Failed to load local model (${MODEL_ID}): ${errorMsg || 'WebAssembly/WebGPU runtime initialization failed.'}`
      });
    }
    return;
  }

  if (type === 'RUN_INVOICE_BUDDY') {
    if (!generator) {
      self.postMessage({
        type: 'TASK_ERROR',
        id,
        error: 'Local model is not loaded. Please initialize the model first before running inference.'
      });
      return;
    }

    try {
      const { userPrompt } = payload;
      if (!userPrompt || typeof userPrompt !== 'string' || userPrompt.trim().length === 0) {
        self.postMessage({
          type: 'TASK_ERROR',
          id,
          error: 'Empty request provided. Please describe the items, services, or work performed.'
        });
        return;
      }

      // Execute actual local model inference
      const modelPrompt = `Format a concise professional invoice item title and description for: ${userPrompt.trim()}`;
      const output = await generator(modelPrompt, {
        max_new_tokens: 50,
        temperature: 0.1,
        repetition_penalty: 1.2
      });

      const rawGenerated = (output[0]?.generated_text || '').trim();
      const cleanedDesc = rawGenerated.length > 3
        ? rawGenerated.replace(/^(task:|generate|request:|format a:)/gi, '').trim()
        : userPrompt.trim();

      // Entity extraction guardrail: safely inspect user's original prompt for quantities, rates, and units
      // Never hallucinate rates or quantities not indicated in prompt
      const rateMatch = userPrompt.match(/\$?\s*([0-9]+(?:\.[0-9]{1,2})?)\s*(?:\/|\s*per\s*)(?:hr|hour|item|unit|mo|month|day)/i)
        || userPrompt.match(/(?:at|for|rate of)\s*\$?\s*([0-9]+(?:\.[0-9]{1,2})?)/i);
      const qtyMatch = userPrompt.match(/([0-9]+(?:\.[0-9]{1,2})?)\s*(?:hours|hrs|hour|units|items|licenses|days|project)/i);

      const parsedRate = rateMatch ? parseFloat(rateMatch[1]) : 0;
      const parsedQty = qtyMatch ? parseFloat(qtyMatch[1]) : 1;
      const parsedUnit = userPrompt.toLowerCase().includes('hour') || userPrompt.toLowerCase().includes('hr')
        ? 'hours'
        : userPrompt.toLowerCase().includes('day')
        ? 'days'
        : 'units';

      const proposal = {
        summary: `Invoice Buddy processed your request using local model ${MODEL_ID}: "${cleanedDesc}"`,
        proposedLineItems: [
          {
            description: cleanedDesc,
            quantity: parsedQty > 0 ? parsedQty : 1,
            unit: parsedUnit,
            unitRate: parsedRate >= 0 ? parsedRate : 0,
            taxable: true
          }
        ],
        proposedNotes: undefined,
        originalPrompt: userPrompt
      };

      self.postMessage({
        type: 'TASK_SUCCESS',
        id,
        proposal
      });
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      self.postMessage({
        type: 'TASK_ERROR',
        id,
        error: `Local model inference error: ${errorMsg || 'Unknown failure'}`
      });
    }
  }
};
