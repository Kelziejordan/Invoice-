import React from 'react';
import { Invoice, BusinessProfile } from '../types';
import { formatCurrency } from '../utils/calc';

interface InvoicePrintViewProps {
  invoice: Invoice;
  business: BusinessProfile;
}

export const InvoicePrintView: React.FC<InvoicePrintViewProps> = ({ invoice, business }) => {
  const accent = invoice.template?.accentColor || '#2563eb';

  return (
    <div
      className="printable-invoice-container mx-auto max-w-4xl bg-white p-6 sm:p-10 shadow-sm rounded-xl border border-slate-200 text-slate-800"
      style={{
        fontFamily: invoice.template?.fontFamily || 'Inter, system-ui, sans-serif'
      }}
    >
      {/* Header Bar */}
      <div
        className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between pb-6 mb-6"
        style={{ borderBottom: `3px solid ${accent}` }}
      >
        <div>
          {business.logoDataUrl ? (
            <img
              src={business.logoDataUrl}
              alt={`${business.name} logo`}
              className="max-h-16 max-w-[220px] object-contain mb-2"
            />
          ) : (
            <h1
              className="text-2xl sm:text-3xl font-extrabold tracking-tight mb-1"
              style={{ color: accent }}
            >
              {business.name}
            </h1>
          )}
          <div className="text-xs sm:text-sm text-slate-600 space-y-0.5 whitespace-pre-line">
            <p>{business.address}</p>
            {business.contactEmail && <p>Email: {business.contactEmail}</p>}
            {business.phone && <p>Tel: {business.phone}</p>}
            {business.taxId && <p>Tax ID / Reg: {business.taxId}</p>}
          </div>
        </div>

        <div className="sm:text-right">
          <h2 className="text-2xl sm:text-3xl font-black uppercase tracking-tight text-slate-700">
            INVOICE
          </h2>
          <div className="text-base sm:text-lg font-bold" style={{ color: accent }}>
            {invoice.invoiceNumber}
          </div>
          <div className="mt-2 text-xs sm:text-sm text-slate-600 space-y-0.5">
            <p>
              <strong className="text-slate-800">Issue Date:</strong> {invoice.issueDate}
            </p>
            <p>
              <strong className="text-slate-800">Due Date:</strong> {invoice.dueDate}
            </p>
            <p>
              <strong className="text-slate-800">Status:</strong>{' '}
              <span className="uppercase font-semibold tracking-wider text-xs">{invoice.status}</span>
            </p>
          </div>
        </div>
      </div>

      {/* Billed To Box */}
      <div className="mb-6 rounded-lg bg-slate-50 p-4 border border-slate-100 text-xs sm:text-sm">
        <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-1">
          Billed To:
        </div>
        <div className="text-base font-bold text-slate-900">
          {invoice.clientSnapshot.name}
        </div>
        <div className="mt-1 text-slate-600 whitespace-pre-line space-y-0.5">
          {invoice.clientSnapshot.billingAddress && <p>{invoice.clientSnapshot.billingAddress}</p>}
          {invoice.clientSnapshot.email && <p>Email: {invoice.clientSnapshot.email}</p>}
          {invoice.clientSnapshot.phone && <p>Phone: {invoice.clientSnapshot.phone}</p>}
        </div>
      </div>

      {/* Line Items Table */}
      <div className="mb-6 overflow-hidden rounded-lg border border-slate-200">
        <table className="w-full text-left text-xs sm:text-sm">
          <thead>
            <tr style={{ background: accent, color: '#ffffff' }}>
              <th scope="col" className="px-4 py-2.5 font-semibold">Description</th>
              <th scope="col" className="px-4 py-2.5 text-center font-semibold">Qty</th>
              <th scope="col" className="px-4 py-2.5 text-right font-semibold">Rate</th>
              <th scope="col" className="px-4 py-2.5 text-right font-semibold">Total</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {invoice.lineItems.map((item, idx) => (
              <tr key={item.id} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}>
                <td className="px-4 py-3">
                  <div className="font-semibold text-slate-800">{item.description}</div>
                </td>
                <td className="px-4 py-3 text-center text-slate-600">
                  {item.quantity} {item.unit}
                </td>
                <td className="px-4 py-3 text-right text-slate-600">
                  {formatCurrency(item.unitRate, invoice.currency)}
                </td>
                <td className="px-4 py-3 text-right font-semibold text-slate-900">
                  {formatCurrency(item.lineTotal, invoice.currency)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Totals Summary */}
      <div className="flex justify-end mb-6 text-xs sm:text-sm">
        <div className="w-full sm:w-72 space-y-2">
          <div className="flex justify-between text-slate-600">
            <span>Subtotal:</span>
            <span className="font-semibold text-slate-800">
              {formatCurrency(invoice.subtotal, invoice.currency)}
            </span>
          </div>

          {invoice.discountAmount > 0 && (
            <div className="flex justify-between text-amber-700">
              <span>Discount ({invoice.discountType === 'percentage' ? `${invoice.discountValue}%` : 'Fixed'}):</span>
              <span>- {formatCurrency(invoice.discountAmount, invoice.currency)}</span>
            </div>
          )}

          <div className="flex justify-between text-slate-600">
            <span>{invoice.taxLabel} ({invoice.taxRate}%):</span>
            <span className="font-semibold text-slate-800">
              {formatCurrency(invoice.taxAmount, invoice.currency)}
            </span>
          </div>

          <div
            className="flex justify-between border-t-2 pt-2 text-base sm:text-lg font-black"
            style={{ borderColor: accent, color: accent }}
          >
            <span>Total Due:</span>
            <span>{formatCurrency(invoice.grandTotal, invoice.currency)}</span>
          </div>
        </div>
      </div>

      {/* Payment Instructions & Notes */}
      <div className="grid grid-cols-1 gap-4 border-t border-slate-200 pt-5 text-xs sm:text-sm sm:grid-cols-2">
        {invoice.paymentInstructions && (
          <div>
            <strong className="block text-slate-800 mb-1">Payment Instructions:</strong>
            <p className="text-slate-600 whitespace-pre-line">{invoice.paymentInstructions}</p>
          </div>
        )}

        {invoice.notes && (
          <div>
            <strong className="block text-slate-800 mb-1">Notes / Terms:</strong>
            <p className="text-slate-600 whitespace-pre-line">{invoice.notes}</p>
          </div>
        )}
      </div>

      {/* Footer Note */}
      {invoice.template?.footerNote && (
        <div className="mt-8 border-t border-dashed border-slate-200 pt-4 text-center text-xs text-slate-400">
          {invoice.template.footerNote}
        </div>
      )}
    </div>
  );
};
