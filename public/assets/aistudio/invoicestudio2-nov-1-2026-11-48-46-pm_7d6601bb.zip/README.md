# Invoice Studio 2

A complete, production-ready, mobile-first, offline-first Invoice Studio web application with a built-in on-device small language model for small businesses.

---

## Overview

**Invoice Studio 2** is engineered to help independent professionals, freelancers, and small businesses create, manage, print, and export invoices from mobile devices and desktop browsers without requiring external servers, database accounts, or paid API keys.

---

## Key Features

1. **Business Profile Management:**
   - Business name, contact email, phone, billing address, website, tax/registration ID.
   - Offline logo upload (stored locally as Base64 data URLs in IndexedDB).
   - Default payment instructions (wire/ACH/bank details).
   - Default currency code (e.g., `USD`, `EUR`, `GBP`).
   - Default tax label (e.g., `Sales Tax`, `VAT`, `GST`) and rate.

2. **Client Directory:**
   - Create, edit, search, and delete client contacts.
   - Saves client name, email, phone, billing address, and internal notes.
   - Historical invoices preserve immutable client snapshots.

3. **Item & Service Library:**
   - Catalog of standard offerings with name, description, unit (`hours`, `units`, `licenses`), rate, and default taxability.
   - Instant auto-fill during invoice creation.

4. **Guided Invoice Builder (Mobile-First):**
   - Step-by-step invoice creation workflow.
   - Dynamic real-time calculation of subtotal, line totals, discounts, and tax.
   - Auto-generated sequential invoice numbers with configurable prefix (`INV-1001`).

5. **Invoice Lifecycle Management:**
   - Statuses: `draft`, `sent`, `paid`, `overdue`, and `cancelled`.
   - Recording of payment received: payment date and amount received.

6. **Precision Financial Calculations:**
   - Floating-point safe rounding (`Math.round((n + Number.EPSILON) * 100) / 100`).
   - Percentage or fixed discounts with proportional allocation across taxable line items.
   - Non-negative totals safeguard.

7. **Browser Print & PDF Generation:**
   - High-fidelity printable invoice view respecting customized template branding and accent colors.
   - Native `window.print()` media styles configured to produce clean PDF invoices without UI chrome or navigation bars.

8. **Offline-First & PWA Compliance:**
   - Local persistence via browser IndexedDB (`InvoiceStudio2_DB`).
   - Resilient error handling for storage quota exhaustion (`QuotaExceededError`).
   - Service Worker precaching (`sw.js`) and Web App Manifest (`manifest.json`) for full installability on iOS and Android.

9. **Cryptographic Backup & Restore:**
   - One-click JSON backup containing all profile data, clients, items, invoices, and templates.
   - Includes SHA-256 integrity checksum (`checksumSha256`).
   - File verification prevents restoration of corrupted or tampered files.

10. **Built-in On-Device LLM ("Invoice Buddy"):**
    - Powered by `@xenova/transformers` running the `Xenova/flan-t5-small` model (~60 MB) inside a dedicated browser Web Worker (`llm.worker.ts`).
    - **Zero API keys required.**
    - Operates 100% offline via browser CacheStorage/IndexedDB after initial weight download.
    - Strict guardrails: parses descriptions and rates without hallucinating client details, amounts, tax rates, or dates.
    - Explicit user confirmation modal: no invoice changes are applied without user review.

---

## Built-In Local LLM Specifications

- **Model Name:** `Xenova/flan-t5-small`
- **Format:** ONNX Quantized q8
- **Download Size:** ~60 MB
- **Source:** Hugging Face model repository (downloaded once on-device)
- **Runtime:** `@xenova/transformers` / ONNX Runtime Web in a dedicated Web Worker (`llm.worker.ts`)
- **API Key Required:** None. Runs directly on the local device via WebAssembly/WebGPU.
- **Offline Behavior:** On first initialization, weights are cached indefinitely in browser CacheStorage / IndexedDB. All subsequent executions occur without any internet connection.
- **Fail-Safe Timeout:** 30 seconds.
- **Guardrails & Provenance:** The model assists with phrasing professional line item descriptions and parsing user prompts. All financial data (quantities, rates, taxes) is verified by the entity guardrail. Every proposed change is displayed in an interactive diff dialog requiring user approval.

---

## Installation & Running

### Requirements
- Node.js >= 18.0.0
- Modern browser (Chrome, Edge, Firefox, Safari)

### Installation
```bash
npm install
```

### Development Server
```bash
npm run dev
```
Navigate to `http://localhost:3000`.

### Run Automated Tests
```bash
npm run test
```

### Production Build
```bash
npm run build
```

---

## Architecture & v1.4.1 Repairs

### 1. IndexedDB Transaction Durability
- Database writes and updates in `/src/services/storage.ts` explicitly wait for `tx.oncomplete` rather than request `onsuccess`.
- Guarantees data durability across unexpected browser terminations or immediate page unloads.

### 2. Clean Defaults & Unconfigured Profile Warning
- Removed all fictitious demonstration data (Acme Solutions Ltd., US address, fake wire/BSB, 8.25% sales tax).
- Clean defaults: Empty business profile with Australian standard 10% GST and AUD currency.
- When business profile has not yet been filled out, a prominent warning alert appears on the Dashboard and Invoice Builder prompting setup before issuing invoices.

### 3. Multi-Turn Conversational Invoice Buddy
- Natural language conversational assistant (`/src/services/buddyEngine.ts`) parsing:
  - Customer identity and matching against existing client directory.
  - Customer billing address, email, and phone.
  - Multiple services, hourly jobs, materials, and item quantities.
  - Issue dates and relative payment terms ("due in 14 days", "net 30").
  - Identifies unpriced services and flags them with `rateRequiresConfirmation`.
  - Seamless "Apply to Invoice Builder" action populating customer, items, dates, and terms directly into the active invoice draft.

### 4. Atomic Workspace Data Restore
- JSON backup restoration executes within a single multi-store IndexedDB transaction (`business`, `clients`, `items`, `invoices`, `templates`).
- If any record fails or validation breaks, the entire transaction automatically aborts and rolls back, preventing corrupt partial state.

### 5. Genuine Integration & Persistence Tests
- Vitest test suite runs with `fake-indexeddb` covering genuine IndexedDB transactions, multi-store rollback, invoice lifecycle transitions, financial precision, and conversational buddy extraction across 7 test suites and 26 test cases.

---

## Supported Environments
- **Desktop:** Chrome >= 95, Edge >= 95, Firefox >= 115, Safari >= 16.4
- **Mobile:** iOS Safari >= 16.4, Android Chrome >= 95
- **Hardware:** Works on standard CPU via WebAssembly (SIMD acceleration recommended).

---

## Known Limitations
- Initial download of the ~60 MB model requires a one-time network connection before offline mode is available for AI features. All other invoice and client features work offline immediately.
- IndexedDB storage capacity is governed by browser storage quota limits (typically multiple gigabytes).
